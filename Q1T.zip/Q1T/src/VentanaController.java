import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/**
 * Controlador para la ventana
 * @author Santiago Faci
 * @version curso 2015-2016
 */
public class VentanaController implements ActionListener, KeyListener {

    private VentanaModelHashMap model;
    private VentanaView view;

    private int posicion;

    public VentanaController(VentanaModelHashMap model, VentanaView view) {
        this.model = model;
        this.view = view;
        anadirActionListener(this);
        anadirKeyListener(this);

        posicion = 0;
    }

    @Override
    public void actionPerformed(ActionEvent event) {
        //JOptionPane.showMessageDialog(null,"Entrando en el método actionPerformed","Mensaje de alerta", JOptionPane.ERROR_MESSAGE);
        String actionCommand = event.getActionCommand();
        Coche coche = null;

        switch (actionCommand) {
            case "nuevo":
                view.tfMatricula.setText("");
                view.tfMatricula.setEditable(true);
                view.tfModelo.setText("");
                view.tfModelo.setEditable(true);
                view.tfFechaCompra.setText("");
                view.tfFechaCompra.setEditable(true);
                view.tfPotencia.setText("");
                view.tfPotencia.setEditable(true);
                view.tfCombustible.setText("");
                view.tfCombustible.setEditable(true);
                view.cbHibrido.setSelected(false);
                view.cbHibrido.setEnabled(true);
                view.btGuardar.setEnabled(true);
                break;
            case "guardar":

                if (view.tfMatricula.getText().equals("")) {
                    //Util.mensajeError("El matricula es un campo obligatorio", "Nuevo coche");
                    JOptionPane.showMessageDialog(null,"La matricula es un campo obligatorio!", "Mensaje de alerta", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                coche = new Coche();
                coche.setMatricula(view.tfMatricula.getText());
                coche.setPotencia(view.tfPotencia.getText());
                coche.setModelo(view.tfModelo.getText());
                coche.setFechaCompra(view.tfFechaCompra.getText());
                coche.setCombustible(view.tfCombustible.getText());
                if (view.cbHibrido.isSelected()) { coche.setHibrido(true); } else { coche.setHibrido(false); }

                model.guardar(coche);

                view.btGuardar.setEnabled(false);
                break;
            case "modificar":
                coche = new Coche();
                coche.setMatricula(view.tfMatricula.getText());
                coche.setPotencia(view.tfPotencia.getText());
                coche.setModelo(view.tfModelo.getText());
                coche.setFechaCompra(view.tfFechaCompra.getText());
                coche.setCombustible(view.tfCombustible.getText());
                if (view.cbHibrido.isSelected()) { coche.setHibrido(true); } else { coche.setHibrido(false); }

                model.modificar(coche);
                break;
            case "cancelar":
                view.tfMatricula.setEditable(false);
                view.tfModelo.setEditable(false);
                view.tfFechaCompra.setEditable(false);
                view.tfPotencia.setEditable(false);
                view.tfCombustible.setEditable(false);
                view.cbHibrido.setEnabled(false);

                coche = model.getActual();
                cargar(coche);

                view.btGuardar.setEnabled(false);
                break;
            case "eliminar":
                if (JOptionPane.showConfirmDialog(null, "¿Está seguro?", "Eliminar", JOptionPane.YES_NO_OPTION) == JOptionPane.NO_OPTION)
                    return;

                model.eliminar(view.tfMatricula.getText());
                coche = model.getActual();
                cargar(coche);
                break;
            case "buscar":
                coche = model.buscar(view.tfBusqueda.getText());
                if (coche == null) {
                    //Util.mensajeInformacion("No se ha encontrado ningún coche con ese matricula", "Buscar");
                    JOptionPane.showMessageDialog(null,"No se ha encontrado ningún coche con ese matricula!","Mensaje de alerta", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                cargar(coche);
                break;
            case "primero":
                coche = model.getPrimero();
                cargar(coche);
                break;
            case "Anterior":
                coche = model.getAnterior();
                cargar(coche);
                break;
            case "siguiente":
                coche = model.getSiguiente();
                cargar(coche);
                break;
            case "ultimo":
                coche = model.getUltimo();
                cargar(coche);
                break;
            default:
                break;
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {

    }

    @Override
    public void keyReleased(KeyEvent e) {

        if (e.getSource() == view.tfBusqueda) {
            if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                view.btBuscar.doClick();
            }
        }
    }

    /**
     * Carga los datos de un coche en la vista
     * @param coche
     */
    private void cargar(Coche coche) {
        if (coche == null)
            return;

        view.tfMatricula.setText(coche.getMatricula());
        view.tfModelo.setText(coche.getModelo());
        view.tfPotencia.setText(coche.getPotencia());
        view.tfFechaCompra.setText(String.valueOf(coche.getFechaCompra()));
        view.tfCombustible.setText(coche.getCombustible());
        view.cbHibrido.setSelected(coche.getHibrido());

    }

    private void anadirKeyListener(KeyListener listener) {
        view.tfBusqueda.addKeyListener(listener);
    }

    private void anadirActionListener(ActionListener listener) {
        //JOptionPane.showMessageDialog(null,"Entrando en el método anadirActionListener","Mensaje de alerta", JOptionPane.ERROR_MESSAGE);
        view.btNuevo.addActionListener(listener);
        view.btGuardar.addActionListener(listener);
        view.btModificar.addActionListener(listener);
        view.btEliminar.addActionListener(listener);
        view.btPrimero.addActionListener(listener);
        view.btAnterior.addActionListener(listener);
        view.btSiguiente.addActionListener(listener);
        view.btUltimo.addActionListener(listener);
        view.btBuscar.addActionListener(listener);
    }
}
