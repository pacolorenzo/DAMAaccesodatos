public class Q2T {

    public static void main(String args[]) {
        VentanaView view = new VentanaView();
        VentanaModelHashMap model = new VentanaModelHashMap();
        VentanaController controller = new VentanaController(model, view);
    }
}
