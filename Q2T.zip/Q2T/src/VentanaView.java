import javax.swing.*;

/**
 *
 *
 * @author Santiago Faci
 * @version curso 2015-2016
 */
public class VentanaView {
    private JPanel panel1;
    JTextField tfMatricula;
    JTextField tfModelo;
    JTextField tfFechaCompra;
    JTextField tfPotencia;
    JTextField tfCombustible;
    JCheckBox cbHibrido;
    JButton btGuardar;
    JButton btNuevo;
    JButton btModificar;
    JButton btEliminar;
    JButton btAnterior;
    JButton btSiguiente;
    JButton btPrimero;
    JButton btUltimo;
    //JBarraEstado barraEstado;
    JProgressBar barraEstado;
    JTextField tfBusqueda;
    JButton btBuscar;

    public VentanaView() {
        //JOptionPane.showMessageDialog(null,"Entrando en el constructor de Ventana","Mensaje de alerta", JOptionPane.ERROR_MESSAGE);
        JFrame frame = new JFrame("Ventana");
        panel1 = new JPanel();
        tfMatricula = new JTextField("matricula");
        tfModelo = new JTextField("modelo");
        tfFechaCompra = new JTextField("fecha compra");
        tfPotencia = new JTextField("potencia");
        tfCombustible = new JTextField("combustible");
        tfBusqueda = new JTextField("busqueda");
        cbHibrido = new JCheckBox("hibrido");
        btGuardar = new JButton("guardar");
        btEliminar = new JButton("eliminar");
        btNuevo = new JButton("nuevo");
        btBuscar = new JButton("buscar");
        btPrimero = new JButton("primero");
        btUltimo = new JButton("ultimo");
        btSiguiente = new JButton("siguiente");
        btAnterior = new JButton("anterior");
        btModificar = new JButton("modificar");
        panel1.add(tfMatricula);
        panel1.add(tfModelo);
        panel1.add(tfFechaCompra);
        panel1.add(tfPotencia);
        panel1.add(tfCombustible);
        panel1.add(cbHibrido);
        panel1.add(tfBusqueda);
        panel1.add(btBuscar);
        panel1.add(btNuevo);
        panel1.add(btGuardar);
        panel1.add(btModificar);
        panel1.add(btEliminar);
        /*panel1.add(btPrimero);
        panel1.add(btUltimo);
        panel1.add(btSiguiente);
        panel1.add(btAnterior);*/
        frame.setContentPane(panel1);
        //JOptionPane.showMessageDialog(null, "Entrando en el constructor de Ventana 2", "Mensaje de alerta", JOptionPane.ERROR_MESSAGE);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
