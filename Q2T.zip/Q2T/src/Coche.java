public class Coche {
    private String matricula;
    private String modelo;
    private String fechaCompra;
    private String potencia;
    private String combustible;
    private Boolean hibrido;

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getFechaCompra() {
        return fechaCompra;
    }

    public void setFechaCompra(String fechaCompra) {
        this.fechaCompra = fechaCompra;
    }

    public String getPotencia() {
        return potencia;
    }

    public void setPotencia(String potencia) {
        this.potencia = potencia;
    }

    public String getCombustible() {
        return combustible;
    }

    public void setCombustible(String combustible) {
        this.combustible = combustible;
    }
    public Boolean getHibrido() {
        return hibrido;
    }

    public void setHibrido(Boolean hibrido) {
        this.hibrido = hibrido;
    }
}
