import javax.swing.*;
import java.io.*;
import java.util.HashMap;

/**
 * Modelo para la ventana
 * @author Santiago Faci
 * @curso 2015-2016
 */
public class VentanaModelHashMap {

    private HashMap<String, Coche> listaCoches;
    private int posicion;

    public VentanaModelHashMap() {
        listaCoches = new HashMap<String, Coche>();
        posicion = 0;
        leerBaseDatos();
    }

    /**
     * Guarda un coche en la lista
     * @param coche
     */
    public void guardar(Coche coche) {

        listaCoches.put(coche.getMatricula(), coche);
        posicion++;
    }

    /**
     * Modifica los datos del coche actual
     * @param cocheModificado
     */
    public void modificar(Coche cocheModificado) {

        Coche coche = listaCoches.get(cocheModificado.getMatricula());
        coche.setMatricula(cocheModificado.getMatricula());
        coche.setModelo(cocheModificado.getModelo());
        coche.setFechaCompra(cocheModificado.getFechaCompra());
        coche.setPotencia(cocheModificado.getPotencia());
        coche.setCombustible(cocheModificado.getPotencia());
        coche.setHibrido(cocheModificado.getHibrido());
    }

    /**
     * Elimina el coche actual
     */
    public void eliminar(String matricula) {

        listaCoches.remove(matricula);
    }

    public Coche getActual() {

        return listaCoches.get(posicion);
    }

    /**
     * Busca un coche en la lista
     * @param matricula del coche
     * @return El coche o null si no se ha encontrado nada
     */
    public Coche buscar(String matricula) {
        try {
            Coche coche = listaCoches.get(matricula);
            return coche;
        } catch (Exception e) {
        }
        return null;
    }

    /**
     * Obtiene el coche que está en primera posición en la lista
     * @return
     */
    public Coche getPrimero() {

        posicion = 0;
        return listaCoches.get(posicion);
    }

    /**
     * Obtiene el coche que está en la posición anterior a la actual
     * @return
     */
    public Coche getAnterior() {

        if (posicion == 0)
            return null;

        posicion--;
        return listaCoches.get(posicion);
    }

    /**
     * Obtiene el coche que está en la posición siguiente a la actual
     * @return
     */
    public Coche getSiguiente() {

        if (posicion == listaCoches.size() - 1)
            return null;

        posicion++;
        return listaCoches.get(posicion);
    }

    /**
     * Obtiene el coche que está en la última posición de la lista
     * @return
     */
    public Coche getUltimo() {

        posicion = listaCoches.size() - 1;
        return listaCoches.get(posicion);
    }

    /**
     * abre el fichero BaseDatos.txt y rellena la clase listaCoches
     * @return
     */
    private void leerBaseDatos() {
        File fichero = null;
        FileReader lector = null;
        BufferedReader buffer = null;
        Coche coche;
        String[] cadena = null;

        try {
            buffer = new BufferedReader(new FileReader(new File("BaseDatos.txt")));
            String linea = null;
            do {
                linea = buffer.readLine();
                if (linea != null) {
                    //JOptionPane.showMessageDialog(null, linea, "Mensaje de alerta", JOptionPane.ERROR_MESSAGE);
                    cadena = linea.split(",");
                    coche = new Coche();
                    coche.setMatricula(cadena[0]);
                    coche.setModelo(cadena[1]);
                    coche.setFechaCompra(cadena[2]);
                    coche.setPotencia(cadena[3]);
                    coche.setCombustible(cadena[4]);
                    if (cadena[5].equals("true")) {
                        coche.setHibrido(true);
                    } else {
                        coche.setHibrido(false);
                    }
                    listaCoches.put(cadena[0], coche);
                }
            } while (linea != null);
        } catch (FileNotFoundException fnfe) {
            fnfe.printStackTrace();
        } catch (IOException ioe) {
            ioe.printStackTrace();
        } finally {
            if (buffer != null)
                try {
                    buffer.close();
                } catch (IOException ioe) {}
        }

    }

    /**
     * graba el fichero BaseDatos.txt desde la clase listaCoches
     * @return
     */
    private void grabarBaseDatos() {
        FileWriter fichero = null;
        PrintWriter escritor = null;

        try {
            fichero = new FileWriter("BaseDatos.txt");
            escritor = new PrintWriter(fichero) ;
            escritor.println("Esto es una linea del fichero");
        } catch (IOException ioe) {
            ioe.printStackTrace() ;
        } finally {
            if (fichero != null)
                try {
                    fichero.close();
                } catch (IOException ioe) {}
        }

    }
}